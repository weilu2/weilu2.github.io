import numpy as np
import pandas as pd
import plotly.graph_objs as go
import plotly.offline as pltof

timesData = pd.read_csv("./input/timesData.csv")
dataframe = timesData[timesData.year == 2015]

trace1 = go.Scatter3d(
    x=dataframe.world_rank,
    y=dataframe.research,
    z=dataframe.citations,
    mode='markers',
    marker=dict(
        size=10,
        color='rgb(255,0,0)'
    )
)

data = [trace1]
layout = go.Layout(
    margin=dict(
        l=0,
        r=0,
        b=0,
        t=0  
    )
    
)
fig = go.Figure(data=data, layout=layout)
pltof.plot(fig)